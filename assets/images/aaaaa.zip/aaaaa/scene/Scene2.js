// this is a class for Scene1

// this file focus on create and update for the game
class Scene2 extends Phaser.Scene {

  // initialize Scene2
	constructor() {
        super("playGame");
	}

  // this function is for creating images on the screen
	create() { 
    // this.lives = 1
  
		///// Create Images /////

        /**** background ****/
        // STEP1: create tileSprite variable called          background
        // hint: this.add.tileSprite(smallest x, smallest    y, biggest x, biggest y, "imageID")
        this.background = this.add.tileSprite(0,0,config.width,config.height,'background')
        
        // STEP2: set origin for the background (set         origin on top left corner)
        // hint: .setOrigin(x, y) will set origin
        this.background.setOrigin(0,0);

        this.background.setScrollFactor(0,1);
            
        /**** player ****/
        // STEP1: create sprite variable called player
        // hint: this.physics.add.sprite(x, y, "imageID")    will add a sprite to the screen
        this.player = this.physics.add.sprite(config.width/2,config.height/2 + 120 ,"player")
        // (optional) customize player size
        // hint: .setScale(number)
        .setScale(1)

        // STEP2: make player cannot go out of screen
        // hint: .body.setCollideWorldBounds(bool)
        this.player.body.setCollideWorldBounds(true)

		

		///// Create Groups /////
		
        /**** enemies ****/
        // STEP1: create group variable named enemies
        // hint: this.physics.add.group() will create a      group
        this.enemies = this.physics.add.group()

        // STEP2: call createEnemies function
        this.createEnemies()

        // STEP3: if enemies overlap with player, call       hurtPlayer function
        // hint: this.physics.add.overlap(sprite, sprite,    function, null, this);
        this.physics.add.overlap(this.player, this.enemies, this.hurtPlayer, null, this);
            
        /**** projectiles ****/
        // STEP1: create group variable named projectiles
        // hint: this.physics.add.group() will create a      group
        this.projectiles = this.physics.add.group();

        // STEP2: if projectiles overlap with enemies,       call hitEnemy function
        // hint: this.physics.add.overlap(sprite, sprite,    function, null, this);
		
        /**** enemyProjectiles ****/
		// STEP1: create group variable named                enemyProjectiles
        // hint: this.add.group() will create a      group

        // STEP2: if enemyProjectiles overlap with player,   call hurtPlayer function
        // hint: this.physics.add.overlap(sprite, sprite,    function, null, this);


		///// Create Controls /////
		
        // cursors include up, down, right, left
        // STEP1: create cursor key variable called          cursors
        // hint: this.input.keyboard.createCursorKeys()      will create cursor keys
        this.cursorKeys = this.input.keyboard.createCursorKeys();

        // spacebar is not included in cursorkeys, so we     need to add it
        // STEP2: create spacebar key variable called        spacebar
        // hint: this.input.keyboard.addKey                  (Phaser.Input.Keyboard.KeyCodes.SPACE) will       create spacebar keys
        this.spacebar = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        this.projectiles = this.add.group()
        ///// Create Texts /////

		/**** Score ****/
        // STEP1: create a variable called score and set     to 0

        // STEP2: create a text variable called scoreText,   set it at the top left corner, print Score:       score
        // hint: this.add.text(x,y,text), you also need      to edit font and fill

		/**** Lives ****/
        // STEP1: create a variable called lives and set     to 3

        // STEP2: create a text variable called livesText,   set it at the top right corner, print Lives:      lives
        // hint: this.add.text(x,y,text), you also need      to edit font and fill

		/**** GameOver ****/
        // STEP1: create a text variable called              gameOverText, set it at the middle of the         screen, print Game Over! \nClick to restart!
        // hint: this.add.text(x,y,text), you also need      to edit font and fill

		// STEP2: set gameOverText not visible
        // hint: .setVisible(bool) will set visible of       text

		/**** Levels ****/
		// STEP1: create a variable called level and set     to 1

        // STEP2: create a variable called difficulty and    set to 1000

        // STEP3: create a text variable called levelText,   set it at top middle, print Level: level
        // hint: this.add.text(x,y,text), you also need      to edit font and fill


		///// Play Animations /////

        // STEP1: let player play its' animation
        // hint: .play("animationID")
        this.player.play('player_idle')
		
	}

  // this function is for moving charactors when start        playing
	update() {
        
    // console.log(this.enemies)
        ///// move background /////

        // STEP1: move background using tilePosition by      0.5
        // hint: .tilePositionY will make image move         vertically, you can also try .tilePositionX to    move horizontally
        this.background.setTilePosition(0,0.5)


        ///// move charactors /////

        // STEP1: call movePlayer, playerShoot,              enemyShoot, levelClear functions
        this.movePlayer();
        this.playerShoot();



        ///// update projectiles /////

        // so they're deleted when off screen

        // STEP1: loop projectiles' children times
        // hint: .getChildren().length will return the       number of children in the group

        // STEP2: create a variable called laser represent    each child in projectiles
        // hint: .getChildren()[number] get each child in    group

        // STEP3: call update fucntion for laser
        // hint: laser is from another class, so you          cannot call this.laser
        

        ///// update enemyProjectiles /////
        
        // so they're deleted when off screen

        // STEP1: loop enemyProjectiles' children times
        // hint: .getChildren().length will return the       number of children in the group

        // STEP2: create a variable called laser represent    each child in enemyProjectiles
        // hint: .getChildren()[number] get each child in    group

        // STEP3: call update fucntion for laser
        // hint: laser is from another class, so you          cannot use this.laser
		
	}


	///// Helper Methods /////


  // this function let player move up, down, left, right      by cursor keys
	movePlayer(){
		
		///// left & right /////

        // STEP1: if left button is down, player goes left
        // hint: left button is included in cursors,         .left.isDown can detect if left button is down,   .body.setVelocityX(number) can set player's       moving speed, Positive and negative of number     is important!
        if(this.cursorKeys.left.isDown){
            this.player.body.setVelocityX(-200)
        }
        // STEP2: else if right button is down, player       goes right
        // hint: .right.isDown can detect if left button     is down
        else if(this.cursorKeys.right.isDown){
          this.player.body.setVelocityX(200)
        }
        // STEP3: else the player don't move
        else{
          this.player.body.setVelocityX(0)
        }

		
		///// up & down /////

        // STEP1: if up button is down, player goes up
        // hint: up button is included in cursors,           .up.isDown can detect if up button is down,       .body.setVelocityY(number) can set player's       moving speed, Positive and negative of number     is important!
        if(this.cursorKeys.up.isDown){
          this.player.body.setVelocityY(-200)
        }
        // STEP2: else if down button is down, player        goes down
        // hint: .down.isDown can detect if down button      is down
        else if(this.cursorKeys.down.isDown){
          this.player.body.setVelocityY(200)
        }
        // STEP3: else the player don't move
        else{
            this.player.body.setVelocityY(0)
        }
	}
	
  // this function let player shoot by space bar
	playerShoot(){
		
        // STEP1: if space button is down
        // hint: we created a spacebar variable in create    (), Phaser.Input.Keyboard.JustDown(key) will      define if a key is down
        if(Phaser.Input.Keyboard.JustDown(this.spacebar)){
          // STEP2: and if player is alive
          // hint: .active will define if player is alive
          if(this.player.active){
            // STEP3: create a variable called playerLaser (which is defined in playerLaser.js)
            // hint: new className(this) will create a new       object from the class
            this.playerLaser = new playerLaser(this);
            // STEP4: add this playerLaser to projectiles       group
            // hint: .add(object) will add object to a group
            // this.projectiles = this.add.group()
          }
        }
        for(var i = 0; i < this.projectiles.getChildren().length; i++){
          var beam = this.projectiles.getChildren()[i]
          beam.update()
        }
	}
	
  // this function create enemies
	createEnemies(){
		
        // STEP1: create 3 lines, each line has 6 objects
        // hint: 2 loops will be applied
        for (var y = 0; y < 2; y++){
          for(var x = 0; x<3;x++){
            // STEP2: inside the loop, create a variable         called enemy and call enemies group to create     enemy each time
            // hint: .create(x, y, "groupID") will create        objects
            var widthx = 100*x
            var widthy = 100*y
            this.enemy =this.enemies.create(150+widthx ,100+widthy,'enemy')
            // (optional) make enemy bigger
            // hint: .setScale(number) will change the size
            .setScale(1)
            
            // STEP3: make the enemy move horizontally
            // hint: .body.velocity.x will change the velocity
            this.enemy.body.velocity.x = -90
            // to make sure they are not always moving at one    direction, we need to set a timer and call        changeEnemyDirection
            // STEP1: create a timer variable and called         enemyTimer, when the time is up, it is going      to call changeEnemyDirection
            // hint: .time.addEvent will add a time event,       you need to set delay(milliseconds), callback,    callbackScope, loop
            // this.enemy
          }
        }
        console.log(this.time)
        this.enemyTimer = this.time.addEvent({
          delay:1500,
          callback: this.changeEnemyDirection,
          callbackScope: this,
          loop:true
        })
	}
	
  // this is going to change enemies to opposite diretion
	changeEnemyDirection() {
		
        // STEP1: for each enemy in enemies group
        // hint: .getChildren().length will get the          total# of children
        var lengrh = this.enemies.getChildren().length
        // STEP2: create a variable, get each children       everytime and call the variable enemy
        // hint: .getChildren()[number] will get each        children
        for (var i = 0; i< lengrh;i++){
            var enemy = this.enemies.getChildren()[i]
            // console.log(enemy.body.velocity)
            enemy.body.velocity.x = enemy.body.velocity.x * -1
        }
        // STEP3: each enemy move to opposite direction      horizontally
        // hint: horizontal direction can be change by       .velocity.x
		
	}
	
  // this enemy let enemy shoot automatically
	enemyShoot() {
		
        // STEP1: for each enemy in enemies group
        // hint: .getChildren().length will get the          total# of children

        // STEP2: create a variable called                   randomEnemyShoot, set enemies shoot 1 to          difficulty times
        // hint: Phaser.Math.Between(numberA, numberB)       will pick random number between numberA and       numberB

        // STEP3: if randomEnemyShoot equals 1

        // STEP4: create new enemyLaser variable
        // hint: new className(scene, enemy) will create     new enemyLaser

        // STEP5: add the enemyLaser to                       enemyProjectiles group
        // hint: .add(object) will add object to group
		
	}
	
  // called when playerProjectile overlap with enemy
	hitEnemy(projectile, enemy) {
		
        // STEP1: create new Explosion variable called       explosion
        // hint: new className(scene, x, y) will create      new class objects

        // STEP2: destroy the projectile passed in
        // .destroy() will destroy an object

        // STEP3: destroy the enemy passed in
        // .destroy() will destroy an object
            
        // STEP4: add score by 15

        // STEP5: update scoreText
        // hint: .text can update text variable

	}
	
  // called when player overlap with enemy
	hurtPlayer(player, enemy) {

        // STEP1: lives are deducted by 1
        // this.lives -= 1;

        // STEP2: update livesText
        // hint: .text will update text variable
        // this.livesText.text = 'Lives: ' + this.lives;
        // STEP3: create new Explosion variable for          player and enemy (two in total)
        // hint: new className(scene, x, y) will create      new class objects
        var playerExplosion = new Explosion(this, player.x, player.y);
        var enemyExplosion = new Explosion(this, enemy.x, enemy.y);
        // STEP4: destroy the enemy passed in
        // hint: .destroy() will destroy the onject
        enemy.destroy()

        // STEP5: player dispear on the screen
        // hint: .disableBody(true, true)
        player.disableBody(true,true)

        // STEP6: if player still has lives

        // STEP7: create a time event and call               resetPlayer function
        // hint: .time.addEvent will add a time event,       you need to set delay(milliseconds), callback,    callbackScope, loop
        this.time.addEvent({
          delay: 1000,
          callback: this.resetPlayer,
          callbackScope: this,
          loop: false
        });

        // STEP8: else if player has no more lives

        // STEP9: set gameOverText visible
        // hint: .setVisible(bool)

        // STEP11: when user click, call restart function
        // hint: .input.once("pointerdown", function,        scene)
		
	}
	
  // called in hurtPlayer, resets player to origin place
	resetPlayer() {
		
        // STEP1: create 2 variables called x & y set        them to the original place when game start
        var x = this.game.config.width / 2;
        var y = this.game.config.height - 100;

        // STEP2: player appear on the screen
        // hint: .enableBody(true, x, y, true, true)
        this.player.enableBody(true, x, y, true, true);
            
        // STEP3: set player's transparency to 0.5 first
        // hint: .alpha will set the transparency (0         means transparent, 1 means solid)
        this.player.alpha =0.5;

        // STEP4: then, create a variable called tween       which add a tween for player to be solid
        // hint: .tweens.add() will add a tween, you will    need to edit targets, y, ease, duration           (milliseconds), repeat, onComplete and            callbackScope
        var tween = this.tweens.add({
          targets: this.player,
          y: config.height - 64,
          ease: 'Power1',
          duration: 1500,
          repeat: 0,
          onComplete: function(){
            this.player.alpha = 1
          },
          callbackScope: this
          // targets: this.player,
          // alpha: 1,
          // ease: 'Linear',
          // duration: 500,
          // repeat: 0,
          // onComplete: function () {},
          // callbackScope: this
        });
		
	}	
	
  // called in hurtPlayer, restart the whole game
	restart() {

        // STEP1: reset lives to 3
        // STEP2: update livesText for lives
        // hint: .text will update text

        // STEP3: reset score to 0
        // STEP4: update scoreText for score
        
        // STEP5: reset level to 1
        // STEP6: reset difficulty to 1000
        // STEP7: update levelText for level
            
        // STEP8: enmpty enemyProjectiles group
        // hint: .clear(true, true) will empty a group

        // STEP9: enmpty enemies group
            
        // STEP10: remove enemyTimer
        // hint: .remove() will remove timer

        // STEP11: call createEnemies to create new          enemies
        // STEP12: call resetPlayer to reset player

        // STEP13: set gameOverText not visible
        // hint: .setVisible(bool) will edit visibility
	
	}

  // called by update(), if no child in enemies group,        update level
	levelClear() {
		
        // STEP1: if enemies group is empty
        // hint: .getChildren().length get children# of a    group

        // STEP2: level go up by 1
        // STEP3: update levelText
        // hint: .text will update text 

        // STEP4: remove enemyTimer
        // hint: .remove() will remove timer

        // STEP5: create new enemies (call createEnemies     function)

        // STEP6: if difficulty greater than 200, deduct     by 100
        // STEP7: else deduct by 10
		
	}
}