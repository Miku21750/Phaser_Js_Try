// this is a class for Scene1
// this file focus on preload and create for the game
class Scene1 extends Phaser.Scene {

  // initialize Scene1
  constructor() {
    super("bootGame");
  }

  // this is the function for loading all the images       before start the game
  preload(){

    // STEP1: load the background image
    // hint: this.load.image("imageID", "image position")    will load the image
    this.load.image('background','assets/images/background.png')

    // STEP2: load sprites of player, beam, enemy            and explosion
    // hint: you are going to create 4 sprites,              this.load.spritesheet("spriteID", "image position")   will load a sprite, and you will also need to set     the frameWidth and frameHeight for each of them
    this.load.spritesheet('player','assets/player.png',{
      frameWidth: 32,
      frameHeight: 48,
    })
    this.load.spritesheet('enemy','assets/enemies.png',{
      frameWidth: 32,
      frameHeight: 32,
    })
    this.load.spritesheet('beam','assets/laser.png',{
      frameWidth: 32,
      frameHeight: 32,
    })
    this.load.spritesheet('explosion','assets/explosion.png',{
      frameWidth: 32,
      frameHeight: 32,
    })
  }

  // this is the function for creating all the images on the screen, start page will also create here
  create() {

    ///// Start Page /////

    // STEP1: create a background variable using the         background you loaded
    // hint: this.add.image(x,y,"imageID") will add the      image to the position you want

    // STEP2: create text for title and start
    // hint: this.add.text(x,y,"text") will add the text     to the position you want, you also need to edit       font and fill

    // STEP3: if click, go to startGame function
    // hint: this.input.on("pointerdown", fucntion, this)
	

    ///// Animations /////

    // STEP1: create animation for each sprite
    // hint: 4 sprites in total, you can create animation    by this.anims.create(), you will need to specify      key, frames, frameRate and repeat (addition           hideOnComplete for explosion)
    this.anims.create({
      key: 'player_idle',
      frames: this.anims.generateFrameNumbers('player'),
      frameRate: 20,
      repeat:-1
    })
    this.anims.create({
      key: 'enemy_idle',
      frames: this.anims.generateFrameNumbers('enemy'),
      frameRate: 20,
      repeat:-1
    })
    this.anims.create({
      key: 'beam_shoot',
      frames: this.anims.generateFrameNumbers('beam'),
      frameRate: 20,
      repeat:-1
    })
    this.anims.create({
      key: 'explode_anim',
      frames: this.anims.generateFrameNumbers('explosion'),
      frameRate: 20,
      hideOnComplete: true
    })
    
    this.startGame();
  }

  // this function is called by code in //Start Page//
  startGame(){
    this.scene.start("playGame");
  }
}

