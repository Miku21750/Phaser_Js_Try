// this is a class for playerLaser
// extends means this playerLaser is also a Sprite object
class playerLaser extends Phaser.GameObjects.Sprite{

  // pass in the scene 
  // so we can use settings from the scene
  constructor(scene) {
    // get player's coordinate(x & y)
    var x = scene.player.x;
    var y = scene.player.y -16; //still debating whether to give them this or not
    
    // get coordinate and laser's animation from scene
    super(scene, x, y, "beam");

    // STEP 1: tell scene this laser now exist
    // hint: scene.add.existing(object) will make object      exist
    scene.add.existing(this)
    // console.log(this.projectiles)
    // STEP 2: tell this laser to play laser's animation
    // hint: object.play(laser's animation ID) will     play the animation
    this.play('beam_shoot')
    // this.projectiles
    // STEP 3: tell scene this laser can move now
    // hint: scene.physics.world.enableBody(object) will      enable the object
    scene.physics.world.enableBody(this);
    // STEP 4: set the speed laser moving from up to    down
    // hint: .body.velocity.y will set object's moving        vertically, .body.velocity.x sets horizontally
    // console.log(this.body.velocity.y)
    this.body.velocity.y = -200
  }

  // set update for this laser
  update(){
    // STEP 5: if this laser moves out of screen,
    // this laser will be destroyed
    // hint: you can try destroy this laser inside      screen first, calling .destroy() will destroy         object
    if(this.projectiles.y < 0){
      this.projectiles.destroy()
    }
  }
}