// this is a class for enemies' lasers
// extends means this laser is also a Sprite object
class enemyLaser extends Phaser.GameObjects.Sprite{

  // pass in the scene and enemy 
  // so we can use settings from the scene
  constructor(scene, enemy) {

    // STEP 1: get enemy's coordinate(x & y)
    // you are going to create 2 variables
    // one for enemy's x, one for enemy's y
    // hint: you can get sprite's x by calling               spritename.x

    // STEP 2: get coordinate and laser's animation     from scene
    // hint: super(scene, sprite's x, sprite's y,            laser's animation ID);

    // STEP 3: tell scene this laser now exist
    // hint: scene.add.existing(object) will make object     exist

    // STEP 4: tell this laser to play laser's animation
    // hint: object.play(laser's animation ID) will play     the animation

    // STEP 5: tell scene this laser can move now
    // hint: scene.physics.world.enableBody(object) will      enable the object
    
    // STEP 6: set the speed laser moving from up to down
    // hint: .body.velocity.y will set object's moving        vertically, .body.velocity.x sets horizontally

    // STEP 7: flip the laser upside down, so when          enemies shoot, they face to the player
    // hint: object.flipY = bool; will flip vertically
    
  }

  // set update for this laser
  update(){

    // STEP 7: if this laser moves out of screen,
    // this laser will be destroyed
    // hint: you can try destroy this laser inside screen    first, calling .destroy() will destroy object

  }
}