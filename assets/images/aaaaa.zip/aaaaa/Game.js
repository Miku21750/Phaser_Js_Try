var config = {
  type: Phaser.AUTO,
  // width and height of screen
  // you can change the size as you want
  width: 512,
  height: 544,
  // 0x000000 is black
  // 0xffff00 is yellow
  backgroundColor: 0x000000,
  scene: [Scene1, Scene2],
	
	physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
};

var gameSettings = {
	playerSpeed: 200
}

// create a new variable called game
// to start a new Phaser game
var game = new Phaser.Game(config);
