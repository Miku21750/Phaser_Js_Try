// this is a class for explosion
// extends means explosion is also a Sprite object
class Explosion extends Phaser.GameObjects.Sprite{

  // pass in the scene and player's x and y
  // so we can use settings from the scene
	constructor(scene,x,y){

    // get scene, coordinate and explosion's animation
    super(scene, x, y, "explosion");

    // STEP 1: tell scene this explosion now exist
    // hint: scene.add.existing(object) will make object      exist
    this.explosion = scene.add.existing(this)

	// STEP 2: tell this explosion to play explosion's animation
    // hint: object.play(explosion's animation ID) will play the animation
    this.explosion.play('explode_anim');
	}
}	